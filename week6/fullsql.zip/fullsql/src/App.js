import Covid from './components/Covid'
import './App.css';


function App() {
  return (
    <div className="App">
     <Covid />
    </div>
  );
}

export default App;
